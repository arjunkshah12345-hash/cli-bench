import pytest

from textproc import camel_to_snake, slugify, truncate, word_frequencies


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Hello, World!", "hello-world"),
        ("  multiple   separators / here  ", "multiple-separators-here"),
        ("Already-slugified", "already-slugified"),
        ("---leading and trailing---", "leading-and-trailing"),
        ("Version 2.0 (beta)", "version-2-0-beta"),
        ("Café déjà vu", "café-déjà-vu"),
        ("", ""),
        ("!!!", ""),
    ],
)
def test_slugify_normalizes_text(text, expected):
    assert slugify(text) == expected


def test_slugify_accepts_a_custom_separator():
    assert slugify("A / B -- C", sep="_") == "a_b_c"


def test_slugify_collapses_mixed_non_alphanumeric_runs():
    assert slugify("one\t\n---two___three", sep=".") == "one.two.three"


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Hello hello HELLO", {"hello": 3}),
        ("one, two! one?", {"one": 2, "two": 1}),
        ("42 42nd 007", {"42": 1, "42nd": 1, "007": 1}),
        ("", {}),
        ("--- ... !!!", {}),
        ("naïve résumé", {"na": 1, "ve": 1, "r": 1, "sum": 1}),
    ],
)
def test_word_frequencies_counts_case_insensitive_ascii_words(text, expected):
    assert word_frequencies(text) == expected


def test_word_frequencies_keeps_internal_apostrophes_with_word_characters():
    assert word_frequencies("Don't stop 'til rock'n'roll; cats' tails") == {
        "don't": 1,
        "stop": 1,
        "til": 1,
        "rock'n": 1,
        "roll": 1,
        "cats": 1,
        "tails": 1,
    }


@pytest.mark.parametrize(
    ("text", "n", "ellipsis", "expected"),
    [
        ("short", 10, "...", "short"),
        ("hello world", 8, "...", "hello..."),
        ("hello", 5, "...", "hello"),
        ("hello", 4, "...", "h..."),
        ("hello", 3, "...", "..."),
        ("hello", 2, "...", ".."),
        ("hello", 0, "...", ""),
        ("hello", 4, "", "hell"),
        ("", 3, "...", ""),
    ],
)
def test_truncate_respects_the_requested_character_limit(
    text, n, ellipsis, expected
):
    result = truncate(text, n, ellipsis)
    assert result == expected
    assert len(result) <= n


def test_truncate_rejects_negative_limits():
    with pytest.raises(ValueError, match="n must be >= 0"):
        truncate("text", -1)


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("CamelCase", "camel_case"),
        ("camelCase", "camel_case"),
        ("HTTPServer", "http_server"),
        ("parseURLValue", "parse_url_value"),
        ("XML2JSON", "xml2_json"),
        ("version2Value", "version2_value"),
        ("already_snake", "already_snake"),
        ("", ""),
        ("lowercase", "lowercase"),
    ],
)
def test_camel_to_snake_handles_case_and_acronym_boundaries(name, expected):
    assert camel_to_snake(name) == expected


def test_camel_to_snake_preserves_non_letter_characters_while_lowercasing():
    assert camel_to_snake("User-ID_Value") == "user-id_value"
