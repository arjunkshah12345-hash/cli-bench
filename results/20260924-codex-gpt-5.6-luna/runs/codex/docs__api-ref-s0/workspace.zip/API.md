# `library` API reference

`library.py` provides five small text/list utilities. The functions do not use
type annotations; the types below describe the inputs they are designed to
accept.

## `chunk_list(items, size)`

Split `items` into consecutive chunks, each containing at most `size` items.
The final chunk may be shorter. Chunks are shallow slices: the values inside
the input are not copied or transformed. For a list input, the return value is
a list of lists.

### Parameters

- `items` (`list`): The list to split.
- `size` (`int`): The maximum number of items per chunk. It must be at least
  `1`.

### Returns

`list`: A list containing the chunks. The result is empty when `items` is
empty. In the implementation, `items` may also be any object that supports
`len(items)` and integer slicing; each chunk has the same slice type as
`items`.

### Exceptions

- `ValueError`: Raised when `size < 1`.
- `TypeError`: Raised when `size` cannot be used as the step in `range()` or
  when `items` does not support the required length and slicing operations.

### Example

```python
from library import chunk_list

chunk_list(["a", "b", "c", "d", "e"], 2)
# [["a", "b"], ["c", "d"], ["e"]]
```

## `flatten(nested, max_depth=10)`

Flatten nested lists into a single list, descending at most `max_depth` list
levels. Non-list values are appended unchanged. Once the depth limit is
reached, a value is appended as-is rather than being inspected further; this
also prevents ordinary cyclic list structures from being followed forever.

### Parameters

- `nested` (any): The value to flatten. Only instances of `list` are
  traversed; tuples and other sequences are treated as individual values.
- `max_depth` (`int`, default `10`): The maximum depth to traverse. A list is
  traversed while the current depth is at most this value. Negative values
  therefore prevent traversal of the root list and return it as one value.

### Returns

`list`: A new list containing the flattened values, preserving their order.

### Exceptions

- `TypeError`: Raised when `max_depth` cannot be compared with an integer.
- `RecursionError`: May be raised if the nesting is deep enough to exceed
  Python's recursion limit before `max_depth` stops traversal. A cyclic list
  is otherwise bounded by `max_depth`.

### Example

```python
from library import flatten

flatten([1, [2, [3]], (4, 5)])
# [1, 2, 3, (4, 5)]
```

## `pluralize(word, count=None)`

Apply a small set of naive English pluralization rules:

- words ending in `s`, `x`, `z`, `ch`, or `sh` receive `"es"`;
- words ending in a consonant followed by `y` change the `y` to `"ies"`;
- all other words receive `"s"`.

If `count == 1`, the original word is returned unchanged. No other grammar,
capitalization, or irregular-plural rules are applied.

### Parameters

- `word` (`str`): The word to pluralize.
- `count` (any, default `None`): Optional count used only for the singular
  special case. Any value equal to `1` causes `word` to be returned unchanged.

### Returns

`str`: Either the original word or the word with the applicable suffix/change.

### Exceptions

- `AttributeError`: Raised when `word` does not provide the string
  `endswith()` operation.
- `TypeError`: May be raised when a non-string `word` cannot be indexed or
  combined with the generated string suffix. A normal `str` input does not
  raise an exception.

### Example

```python
from library import pluralize

pluralize("box")
# "boxes"
pluralize("city")
# "cities"
pluralize("cat", count=1)
# "cat"
```

## `truncate_chars(s, n, ellipsis="…")`

Limit a string to at most `n` characters. If truncation is needed, append
`ellipsis`, counting the ellipsis characters within the limit. If `n` is less
than or equal to the length of `ellipsis`, the ellipsis itself is truncated to
`n` characters. An empty string is returned for `n == 0`.

The function truncates based on Python string length and slicing; it does not
perform word-boundary or grapheme-cluster handling. Note that a string whose
length is exactly `n` is treated as needing truncation.

### Parameters

- `s` (`str`): The string to truncate.
- `n` (`int`): The maximum requested length. It must be non-negative.
- `ellipsis` (`str`, default `"…"`): The suffix used when truncation occurs.

### Returns

`str`: The original string when `len(s) < n`; otherwise, a string made from a
prefix of `s` and the ellipsis (or a prefix of the ellipsis when `n` is small).

### Exceptions

- `ValueError`: Raised when `n < 0`.
- `TypeError`: May be raised when `n` is not comparable with an integer or
  usable as a slice bound, or when `s`/`ellipsis` do not support the required
  length, slicing, and string-concatenation operations.

### Example

```python
from library import truncate_chars

truncate_chars("A long title", 8)
# "A long …"
truncate_chars("A long title", 1)
# "…"
```

## `valid_identifier(s)`

Return whether `s` is a valid Python identifier and is not a Python keyword.
For example, `"class"` is rejected even though it has valid identifier
syntax.

### Parameters

- `s` (`str`): The candidate identifier.

### Returns

`bool`: `True` when `s.isidentifier()` is true and `keyword.iskeyword(s)` is
false; otherwise `False`.

### Exceptions

- `AttributeError`: Raised when `s` does not provide the string
  `isidentifier()` operation.
- `TypeError`: May be raised by `keyword.iskeyword()` for an object that is
  not a string-like value after a custom `isidentifier()` result. A normal
  `str` input does not raise an exception.

### Example

```python
from library import valid_identifier

valid_identifier("user_name")  # True
valid_identifier("class")      # False
valid_identifier("2users")     # False
```
