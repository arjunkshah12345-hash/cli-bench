"""Thread-safe token-bucket rate limiter."""

from __future__ import annotations

import math
import threading
import time
from numbers import Integral, Real


class TokenBucketLimiter:
    """Limit work to ``rate`` tokens per second with a bounded burst."""

    def __init__(self, rate: float, capacity: int):
        if isinstance(rate, bool) or not isinstance(rate, Real) or not math.isfinite(rate):
            raise ValueError("rate must be a finite non-negative number")
        if rate < 0:
            raise ValueError("rate must be non-negative")
        if isinstance(capacity, bool) or not isinstance(capacity, Integral):
            raise ValueError("capacity must be a positive integer")
        if capacity <= 0:
            raise ValueError("capacity must be a positive integer")

        self.rate = float(rate)
        self.capacity = int(capacity)
        self._tokens = float(self.capacity)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    @staticmethod
    def _validate_request(n: int) -> int:
        if isinstance(n, bool) or not isinstance(n, Integral) or n <= 0:
            raise ValueError("n must be a positive integer")
        return int(n)

    def _tokens_at(self, now: float) -> float:
        """Return the available tokens at *now* without changing state."""
        elapsed = max(0.0, now - self._last_refill)
        return min(float(self.capacity), self._tokens + elapsed * self.rate)

    def _commit(self, tokens: float, now: float) -> None:
        self._tokens = tokens
        self._last_refill = now

    def acquire(self, n=1) -> bool:
        """Atomically consume ``n`` tokens if enough are currently available."""
        n = self._validate_request(n)
        with self._lock:
            now = time.monotonic()
            tokens = self._tokens_at(now)
            if n > self.capacity or tokens < n:
                return False
            self._commit(tokens - n, now)
            return True

    def retry_after(self, n=1) -> float:
        """Return the estimated seconds until ``n`` tokens can be acquired."""
        n = self._validate_request(n)
        with self._lock:
            now = time.monotonic()
            tokens = self._tokens_at(now)
            if n > self.capacity:
                return math.inf
            if tokens >= n:
                return 0.0
            if self.rate == 0.0:
                return math.inf
            return (n - tokens) / self.rate

    def try_acquire_all(self, requests) -> bool:
        """Consume a sequence atomically, rolling back entirely on failure."""
        requests = list(requests)
        amounts = [self._validate_request(n) for n in requests]

        with self._lock:
            now = time.monotonic()
            tokens = self._tokens_at(now)
            if any(n > self.capacity for n in amounts):
                return False
            total = sum(amounts)
            if tokens < total:
                return False
            self._commit(tokens - total, now)
            return True
