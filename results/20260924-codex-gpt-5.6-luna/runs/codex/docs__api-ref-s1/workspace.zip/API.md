# `library` API reference

`library.py` provides small utilities for working with lists and text. The
functions below are the public API.

## `chunk_list(items, size)`

Split a list into consecutive chunks, each containing at most `size` items.
The final chunk may be shorter than the others. The input list is not modified.

### Parameters

- `items` (`list`): The list to split. Its elements are preserved in their
  original order.
- `size` (`int`): The maximum number of items in each chunk. It must be at
  least 1.

### Returns

`list[list]`: A new list of list slices. An empty input produces an empty
list.

### Exceptions

- `ValueError`: Raised when `size < 1`.
- `TypeError`: Raised when `items` does not support `len()` and slicing, or
  when `size` cannot be compared with `1` or used as the step in `range()`.

### Example

```python
from library import chunk_list

chunk_list([1, 2, 3, 4, 5], 2)
# [[1, 2], [3, 4], [5]]
```

## `flatten(nested, max_depth=10)`

Flatten nested lists into a single list, traversing at most `max_depth` list
levels. Non-list values are appended unchanged. Once the recursion depth is
greater than `max_depth`, a list is treated as a value and appended as-is;
this also prevents traversal of a cyclic list after the cutoff is reached.

The initial value is processed at depth 0. Consequently, with
`max_depth=0`, a top-level list is flattened one level, while lists found
inside it are retained.

### Parameters

- `nested` (any): The value to flatten. Only objects whose type is `list`
  are traversed; tuples and other iterable values are retained as individual
  values.
- `max_depth` (`int`, default `10`): The maximum recursion depth used for
  list traversal. Values below zero cause the initial value to be retained
  without traversing it. The implementation accepts other values that can be
  compared with an integer, although an integer is the intended type.

### Returns

`list`: A new flat list containing the encountered non-list values and any
lists retained at the depth cutoff.

### Exceptions

- `TypeError`: Raised if `max_depth` cannot be compared with an integer.
- `RecursionError`: May be raised for sufficiently large `max_depth` and
  deeply nested input, because the implementation uses Python recursion.

### Example

```python
from library import flatten

flatten(["a", ["b", ["c"]]])
# ['a', 'b', 'c']

flatten(["a", ["b", ["c"]]], max_depth=1)
# ['a', 'b', ['c']]
```

## `pluralize(word, count=None)`

Produce a naive English plural form. Words ending in `s`, `x`, `z`, `ch`, or
`sh` receive `-es`; words ending in a consonant followed by `y` change the
`y` to `-ies`; all other words receive `-s`.

If `count` is exactly equal to `1`, the word is returned unchanged. Otherwise
the plural rules are applied. This is a deliberately simple rule set and does
not handle irregular nouns or capitalization specially.

### Parameters

- `word` (`str`): The word to pluralize.
- `count` (any, default `None`): Optional count. When `count == 1`, return
  `word` unchanged; any other value uses the plural form.

### Returns

`str`: Either the unchanged singular word or its naive plural form.

### Exceptions

- `AttributeError`: Raised when `word` does not provide the string method
  `.endswith()`.
- `TypeError`: May be raised by `.endswith()` or string concatenation when
  `word` is not a compatible string-like value.

### Example

```python
from library import pluralize

pluralize("box")
# 'boxes'
pluralize("party")
# 'parties'
pluralize("cat", count=1)
# 'cat'
```

## `truncate_chars(s, n, ellipsis="…")`

Truncate a string to at most `n` characters. If `len(s) >= n` and `n > 0`,
the result ends with `ellipsis`, and the ellipsis characters are included in
the `n`-character limit. If `s` is shorter than `n`, it is returned unchanged.
For `n == 0`, the result is always the empty string. If `n` is positive but
no larger than the length of `ellipsis`, the result is the first `n`
characters of `ellipsis`.

### Parameters

- `s` (`str`): The string to truncate.
- `n` (`int`): The maximum output length. It must be non-negative.
- `ellipsis` (`str`, default `"…"`): The suffix used when truncation occurs.
  Its length counts toward the output limit.

### Returns

`str`: The original string when its length is less than `n`, otherwise a
prefix followed by the ellipsis (or a prefix of the ellipsis when `n` is too
small to include it in full).

### Exceptions

- `ValueError`: Raised when `n < 0`.
- `TypeError`: Raised when `s` or `ellipsis` does not support the required
  string operations, or when `n` is not a valid integer-like value for
  slicing and `range`-style indexing.

### Example

```python
from library import truncate_chars

truncate_chars("Hello, world!", 8)
# 'Hello, …'

truncate_chars("Hi", 8)
# 'Hi'
```

## `valid_identifier(s)`

Return whether `s` is a valid Python identifier that is not a Python keyword.
Thus names such as `"name"` are valid, while `"class"` is rejected even
though it has valid identifier syntax.

### Parameters

- `s` (`str`): The candidate identifier.

### Returns

`bool`: `True` when `s.isidentifier()` is true and `s` is not a Python
keyword; otherwise `False`.

### Exceptions

- `AttributeError`: Raised when `s` does not provide the `.isidentifier()`
  method.
- Other exceptions from a custom object's `.isidentifier()` method are not
  caught and are propagated unchanged.

### Example

```python
from library import valid_identifier

valid_identifier("user_name")
# True
valid_identifier("class")
# False
valid_identifier("user-name")
# False
```
