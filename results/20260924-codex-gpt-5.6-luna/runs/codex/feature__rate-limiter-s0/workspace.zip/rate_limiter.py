"""Thread-safe token-bucket rate limiting."""

from __future__ import annotations

import math
import threading
import time


class TokenBucketLimiter:
    """A token bucket that refills continuously at ``rate`` tokens/second."""

    def __init__(self, rate: float, capacity: int):
        if isinstance(rate, bool) or not isinstance(rate, (int, float)):
            raise TypeError("rate must be a number")
        if not math.isfinite(rate) or rate < 0:
            raise ValueError("rate must be finite and non-negative")
        if isinstance(capacity, bool) or not isinstance(capacity, int):
            raise TypeError("capacity must be an integer")
        if capacity <= 0:
            raise ValueError("capacity must be positive")

        self.rate = float(rate)
        self.capacity = capacity
        self._tokens = float(capacity)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    @staticmethod
    def _validate_request(n: int) -> None:
        if isinstance(n, bool) or not isinstance(n, int):
            raise TypeError("n must be a positive integer")
        if n <= 0:
            raise ValueError("n must be a positive integer")

    def _refill(self, now: float) -> None:
        elapsed = now - self._last_refill
        if elapsed > 0:
            self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
            self._last_refill = now

    def acquire(self, n=1) -> bool:
        """Atomically consume ``n`` tokens if they are currently available."""
        self._validate_request(n)
        if n > self.capacity:
            return False

        with self._lock:
            self._refill(time.monotonic())
            if self._tokens < n:
                return False
            self._tokens -= n
            return True

    def retry_after(self, n=1) -> float:
        """Return the estimated wait, in seconds, for ``n`` available tokens."""
        self._validate_request(n)
        if n > self.capacity:
            return math.inf

        with self._lock:
            self._refill(time.monotonic())
            if self._tokens >= n:
                return 0.0
            if self.rate == 0:
                return math.inf
            return (n - self._tokens) / self.rate

    def try_acquire_all(self, requests) -> bool:
        """Consume every request atomically, or leave the bucket unchanged."""
        requests = list(requests)
        for n in requests:
            self._validate_request(n)

        with self._lock:
            now = time.monotonic()
            old_tokens = self._tokens
            old_last_refill = self._last_refill
            self._refill(now)

            candidate = self._tokens
            for n in requests:
                if n > self.capacity or candidate < n:
                    # Restore both fields: a failed batch is observationally
                    # identical to no operation (including its refill time).
                    self._tokens = old_tokens
                    self._last_refill = old_last_refill
                    return False
                candidate -= n

            self._tokens = candidate
            return True
