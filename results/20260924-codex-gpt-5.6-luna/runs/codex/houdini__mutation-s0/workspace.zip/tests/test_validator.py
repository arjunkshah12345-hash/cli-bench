import pytest

from validator import validate_email, validate_username


@pytest.mark.parametrize("username", ["abc", "abc2", "a_b", "Z" * 20])
def test_validate_username_accepts_valid_shapes(username):
    assert validate_username(username) is True


@pytest.mark.parametrize("username", ["ab", "a" * 21, "", "a b", "a-b"])
def test_validate_username_rejects_wrong_length_or_characters(username):
    assert validate_username(username) is False


@pytest.mark.parametrize("username", ["1alice", "_alice", "-alice"])
def test_validate_username_must_start_with_a_letter(username):
    assert validate_username(username) is False


@pytest.mark.parametrize("username", [None, 123, b"alice", ["alice"]])
def test_validate_username_rejects_non_strings(username):
    assert validate_username(username) is False


@pytest.mark.parametrize("email", ["a@b.c", "first.last@example.org", "x@y.z"])
def test_validate_email_accepts_a_basic_dotted_domain(email):
    assert validate_email(email) is True


@pytest.mark.parametrize("email", ["", "@example.com", "user@", "userexample.com"])
def test_validate_email_requires_non_empty_parts_and_at_sign(email):
    assert validate_email(email) is False


@pytest.mark.parametrize("email", ["a@b", "a@example", "a@examplecom"])
def test_validate_email_requires_a_dotted_domain(email):
    assert validate_email(email) is False


@pytest.mark.parametrize("email", ["a@@b.c", "a@b@c.d", "a b@c.d", "a@b c.d"])
def test_validate_email_rejects_multiple_at_signs_or_spaces(email):
    assert validate_email(email) is False


@pytest.mark.parametrize("email", [None, 42, b"a@b.c", ["a@b.c"]])
def test_validate_email_rejects_non_strings(email):
    assert validate_email(email) is False
