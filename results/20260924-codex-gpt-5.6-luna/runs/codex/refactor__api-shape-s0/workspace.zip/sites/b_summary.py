"""Call site B: summary stats."""

from pkg.geometry import circle_circumference, rect_perimeter


def summarize(rects, circles):
    per = sum(rect_perimeter(w, h) for w, h in rects)
    cir = sum(circle_circumference(r) for r in circles)
    return {"total_rect_perimeter": per, "total_circle_circumference": cir}
