"""Geometry package."""
