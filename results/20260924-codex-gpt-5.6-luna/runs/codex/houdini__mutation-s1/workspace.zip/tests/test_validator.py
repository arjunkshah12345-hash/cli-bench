import pytest

from validator import validate_email, validate_username


@pytest.mark.parametrize(
    "username",
    [
        "abc",
        "a" * 20,
        "alice_123",
        "A9_b2",
        "éclair",
    ],
)
def test_validate_username_accepts_valid_usernames(username):
    assert validate_username(username) is True


@pytest.mark.parametrize(
    "username",
    [
        None,
        123,
        b"alice",
        "",
        "ab",  # below the minimum length
        "a" * 21,  # above the maximum length
        "1alice",  # must begin with a letter
        "_alice",  # must begin with a letter
        "alice-name",
        "alice name",
        "alice.name",
        "alice!",
    ],
)
def test_validate_username_rejects_nonmatching_values(username):
    assert validate_username(username) is False


@pytest.mark.parametrize(
    "email",
    [
        "a@b.c",
        "alice@example.com",
        "first.last+tag@mail.example.co.uk",
        "user-name@sub-domain.example",
    ],
)
def test_validate_email_accepts_dotted_domain_shapes(email):
    assert validate_email(email) is True


@pytest.mark.parametrize(
    "email",
    [
        None,
        123,
        b"a@b.c",
        "",
        "@example.com",  # missing local part
        "alice@",  # missing domain
        "alice.example.com",  # missing @
        "alice@example",  # domain is not dotted
        "alice@example.com@other.com",  # more than one @
        "alice @example.com",
        "alice@example .com",
    ],
)
def test_validate_email_rejects_nonmatching_values(email):
    assert validate_email(email) is False
