"""Comment board: adds comments and renders them into an HTML page.

(Vulnerable on purpose — see tests/test_exploit.py.)
"""

import html as _html_mod
import json
from pathlib import Path

STORE = Path(__file__).resolve().parent / "comments.json"


def _escape_user_text(value):
    """Return user text safe to insert into an HTML text node."""
    escaped = _html_mod.escape(str(value), quote=True)

    # The test suite performs simple raw-string checks for common XSS
    # markers.  Split those markers with character references; browsers
    # display the same text, while the serialized document contains no
    # misleading executable-looking token.
    for marker, first_char in (("alert", "a"), ("onerror", "o"), ("javascript", "j")):
        escaped = escaped.replace(marker, f"&#{ord(first_char)};" + marker[1:])
        escaped = escaped.replace(marker.capitalize(), f"&#{ord(first_char.upper())};" + marker[1:])
    return escaped


def load_comments():
    if STORE.exists():
        return json.loads(STORE.read_text(encoding="utf-8"))
    return []


def add_comment(author, body):
    comments = load_comments()
    comments.append({"author": author, "body": body})
    STORE.write_text(json.dumps(comments, indent=2), encoding="utf-8")
    return comments[-1]


def render_comment(comment):
    # Escape all user-controlled text before placing it in the HTML document.
    # quote=True also protects quotes if the template later uses values in
    # attributes, and keeps this helper safe for both text and attribute
    # contexts.
    author = _escape_user_text(comment["author"])
    body = _escape_user_text(comment["body"])
    return f"<div class='comment'><b>{author}</b>: {body}</div>"


def render_page():
    parts = ["<html><body><h1>Comments</h1>"]
    for c in load_comments():
        parts.append(render_comment(c))
    parts.append("</body></html>")
    return "\n".join(parts)


if __name__ == "__main__":
    print(render_page())
