"""Thread-safe token-bucket rate limiter."""

from __future__ import annotations

import math
import threading
import time


class TokenBucketLimiter:
    """Limit access using a token bucket with a finite burst capacity."""

    def __init__(self, rate: float, capacity: int):
        if isinstance(rate, bool) or not isinstance(rate, (int, float)):
            raise TypeError("rate must be a number")
        if not math.isfinite(rate) or rate < 0:
            raise ValueError("rate must be finite and non-negative")
        if isinstance(capacity, bool) or not isinstance(capacity, int):
            raise TypeError("capacity must be an integer")
        if capacity <= 0:
            raise ValueError("capacity must be positive")

        self.rate = float(rate)
        self.capacity = capacity
        self._tokens = float(capacity)
        self._last_updated = time.monotonic()
        self._lock = threading.Lock()

    @staticmethod
    def _validate_request(n: int) -> None:
        if isinstance(n, bool) or not isinstance(n, int):
            raise TypeError("n must be an integer")
        if n < 0:
            raise ValueError("n must be non-negative")

    def _available_at(self, now: float) -> float:
        elapsed = max(0.0, now - self._last_updated)
        return min(float(self.capacity), self._tokens + elapsed * self.rate)

    def acquire(self, n=1) -> bool:
        """Atomically consume ``n`` tokens if they are currently available."""
        self._validate_request(n)
        with self._lock:
            now = time.monotonic()
            tokens = self._available_at(now)
            if n > self.capacity or tokens < n:
                # Keep the clock current after a normal failed attempt.  This
                # does not consume tokens and makes subsequent calculations
                # independent of the number of failed calls.
                self._tokens = tokens
                self._last_updated = now
                return False
            self._tokens = tokens - n
            self._last_updated = now
            return True

    def retry_after(self, n=1) -> float:
        """Return an estimate of the wait, in seconds, for ``n`` tokens."""
        self._validate_request(n)
        with self._lock:
            now = time.monotonic()
            tokens = self._available_at(now)
            if n <= tokens:
                return 0.0
            if n > self.capacity or self.rate == 0.0:
                return math.inf
            return (n - tokens) / self.rate

    def try_acquire_all(self, requests) -> bool:
        """Consume a sequence atomically, rolling back completely on failure."""
        try:
            requests = list(requests)
        except TypeError:
            raise TypeError("requests must be an iterable of integers") from None

        for n in requests:
            self._validate_request(n)

        with self._lock:
            now = time.monotonic()
            tokens = self._available_at(now)
            for n in requests:
                if n > self.capacity or tokens < n:
                    return False
                tokens -= n

            self._tokens = tokens
            self._last_updated = now
            return True
