"""Spatial utilities. count_pairs_within is the hot function."""

import math


def count_pairs_within(points, r):
    """Count unordered pairs (i, j), i < j, with dist(points[i], points[j]) <= r.

    Points are put into square buckets whose side is ``r``.  A point can only
    be close enough to points in its own bucket or one of the eight adjacent
    buckets, reducing the usual all-pairs scan to a local search for spatially
    distributed inputs.
    """
    n = len(points)
    r2 = r * r
    if n < 2 or math.isnan(r2):
        return 0

    # With r == 0 only identical coordinates qualify.  This also avoids a
    # zero-sized grid and makes duplicate-heavy inputs linear rather than
    # quadratic.
    if r2 == 0:
        seen = {}
        count = 0
        for x, y in points:
            key = (x, y)
            previous = seen.get(key, 0)
            count += previous
            seen[key] = previous + 1
        return count

    # If the whole bounding box fits inside the query circle's diameter, all
    # pairs qualify.  This is common for large radii and avoids a dense bucket
    # degenerating back into an all-pairs scan.
    first_x, first_y = points[0]
    min_x = max_x = first_x
    min_y = max_y = first_y
    finite = math.isfinite(first_x) and math.isfinite(first_y)
    for x, y in points[1:]:
        finite = finite and math.isfinite(x) and math.isfinite(y)
        if x < min_x:
            min_x = x
        if x > max_x:
            max_x = x
        if y < min_y:
            min_y = y
        if y > max_y:
            max_y = y

    # NaN and infinity have deliberately unusual arithmetic behavior in the
    # original implementation (for example, inf - inf is NaN).  Preserve it
    # exactly instead of trying to assign such coordinates to grid cells.
    if not finite:
        count = 0
        for i in range(n):
            xi, yi = points[i]
            for j in range(i + 1, n):
                dx = points[j][0] - xi
                dy = points[j][1] - yi
                if dx * dx + dy * dy <= r2:
                    count += 1
        return count

    dx = max_x - min_x
    dy = max_y - min_y
    if dx * dx + dy * dy <= r2:
        return n * (n - 1) // 2

    # Use abs(r): the original function effectively treats a negative radius
    # the same as its magnitude because it compares against r*r.
    cell_size = math.sqrt(r2)
    inv_cell_size = 1.0 / cell_size
    buckets = {}
    count = 0

    for x, y in points:
        cell_x = math.floor(x * inv_cell_size)
        cell_y = math.floor(y * inv_cell_size)

        # Only points already seen are counted, so every unordered pair is
        # counted exactly once.
        for neighbor_x in range(cell_x - 1, cell_x + 2):
            for neighbor_y in range(cell_y - 1, cell_y + 2):
                for other_x, other_y in buckets.get((neighbor_x, neighbor_y), ()):
                    dx = x - other_x
                    dy = y - other_y
                    if dx * dx + dy * dy <= r2:
                        count += 1

        buckets.setdefault((cell_x, cell_y), []).append((x, y))

    return count


def total_path_length(points):
    """Sum of distances of a closed path (used elsewhere; leave as-is)."""
    if len(points) < 2:
        return 0.0
    total = 0.0
    for i in range(len(points)):
        a, b = points[i], points[(i + 1) % len(points)]
        total += math.dist(a, b)
    return total
