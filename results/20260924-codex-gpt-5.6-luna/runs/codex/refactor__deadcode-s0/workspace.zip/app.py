import math


def add(a, b):
    """Add two numbers."""
    return a + b


def sub(a, b):
    """Subtract b from a."""
    return a - b


def mul(a, b):
    """Multiply two numbers."""
    return a * b


def circle_area(radius):
    """Area of a circle."""
    return math.pi * radius * radius


def mean(xs):
    if not xs:
        raise ValueError("empty")
    return sum(xs) / len(xs)


def stddev(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))
