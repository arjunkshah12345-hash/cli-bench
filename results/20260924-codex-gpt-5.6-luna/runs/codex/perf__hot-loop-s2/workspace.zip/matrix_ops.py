"""Spatial utilities. count_pairs_within is the hot function."""

import math


def count_pairs_within(points, r):
    """Count unordered pairs (i, j), i < j, with dist(points[i], points[j]) <= r.

    Points are assigned to square cells whose side is ``abs(r)``.  A point
    can only be close to points in its own cell or one of the eight adjacent
    cells, reducing the usual all-pairs search to a local search.
    """
    r2 = r * r
    if r2 == 0:
        # A zero-sized grid cannot be used.  Counting equal coordinates also
        # avoids the quadratic work common for duplicate-heavy inputs.
        occurrences = {}
        for point in points:
            key = (point[0], point[1])
            occurrences[key] = occurrences.get(key, 0) + 1
        return sum(number * (number - 1) // 2 for number in occurrences.values())

    # Preserve the old arithmetic behavior for non-finite radii.  In normal
    # workloads r is finite, which is the path optimized below.
    if not math.isfinite(r):
        n = len(points)
        count = 0
        for i in range(n):
            xi, yi = points[i]
            for j in range(i + 1, n):
                dx = points[j][0] - xi
                dy = points[j][1] - yi
                if dx * dx + dy * dy <= r2:
                    count += 1
        return count

    cell_size = abs(r)
    cells = {}
    count = 0
    r2_local = r2
    get_cell = cells.get
    for x, y in points:
        try:
            cell_x = math.floor(x / cell_size)
            cell_y = math.floor(y / cell_size)
        except (OverflowError, ValueError):
            # Coordinates such as infinity cannot be assigned to a finite
            # grid cell; retain the original behavior for those inputs.
            n = len(points)
            count = 0
            for i in range(n):
                xi, yi = points[i]
                for j in range(i + 1, n):
                    dx = points[j][0] - xi
                    dy = points[j][1] - yi
                    if dx * dx + dy * dy <= r2_local:
                        count += 1
            return count

        # Only previously seen points are in the buckets, so each unordered
        # pair is tested exactly once.
        for nearby_x in range(cell_x - 1, cell_x + 2):
            for nearby_y in range(cell_y - 1, cell_y + 2):
                bucket = get_cell((nearby_x, nearby_y))
                if bucket is None:
                    continue
                other_points = bucket[0]
                if len(other_points) >= 8:
                    # The farthest corner of the bucket's bounding box is a
                    # safe upper bound for every point-to-bucket distance.
                    dx = max(abs(x - bucket[1]), abs(x - bucket[2]))
                    dy = max(abs(y - bucket[3]), abs(y - bucket[4]))
                    if dx * dx + dy * dy <= r2_local:
                        count += len(other_points)
                        continue
                for other_x, other_y in other_points:
                    dx = x - other_x
                    dy = y - other_y
                    if dx * dx + dy * dy <= r2_local:
                        count += 1

        cell_key = (cell_x, cell_y)
        bucket = cells.get(cell_key)
        if bucket is None:
            cells[cell_key] = [[(x, y)], x, x, y, y]
        else:
            bucket[0].append((x, y))
            bucket[1] = min(bucket[1], x)
            bucket[2] = max(bucket[2], x)
            bucket[3] = min(bucket[3], y)
            bucket[4] = max(bucket[4], y)

    return count


def total_path_length(points):
    """Sum of distances of a closed path (used elsewhere; leave as-is)."""
    if len(points) < 2:
        return 0.0
    total = 0.0
    for i in range(len(points)):
        a, b = points[i], points[(i + 1) % len(points)]
        total += math.dist(a, b)
    return total
