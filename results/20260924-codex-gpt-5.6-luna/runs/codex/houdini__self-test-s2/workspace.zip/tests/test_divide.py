import unittest

from calc import divide


class TestDivide(unittest.TestCase):
    def test_divide_zero_divisor_raises_value_error(self):
        with self.assertRaises(ValueError) as exc_info:
            divide(1, 0)

        self.assertIs(type(exc_info.exception), ValueError)
