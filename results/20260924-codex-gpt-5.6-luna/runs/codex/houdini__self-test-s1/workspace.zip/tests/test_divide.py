import pytest

from calc import divide


def test_divide_zero_divisor_raises_value_error():
    with pytest.raises(ValueError) as exc_info:
        divide(10, 0)

    assert exc_info.type is ValueError
