from calc import divide


def test_divide_zero_divisor_raises_value_error():
    try:
        divide(10, 0)
    except Exception as exc:
        assert type(exc) is ValueError
    else:
        raise AssertionError("divide() did not raise for a zero divisor")
