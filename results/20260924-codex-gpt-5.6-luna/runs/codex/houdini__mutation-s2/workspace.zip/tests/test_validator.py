import pytest

from validator import validate_email, validate_username


@pytest.mark.parametrize(
    "username",
    [
        "abc",
        "a" * 20,
        "Alice_123",
        "a_b",
    ],
)
def test_validate_username_accepts_valid_values(username):
    assert validate_username(username) is True


@pytest.mark.parametrize(
    "username",
    [
        "ab",  # below the minimum length
        "a" * 21,  # above the maximum length
        "1abc",  # must begin with a letter
        "_abc",  # must begin with a letter
        "ab-c",  # hyphens are not allowed
        "ab.c",  # punctuation is not allowed
        "ab c",  # whitespace is not allowed
        "",
    ],
)
def test_validate_username_rejects_invalid_values(username):
    assert validate_username(username) is False


@pytest.mark.parametrize("value", [None, 123, b"alice", [], {}])
def test_validate_username_rejects_non_strings(value):
    assert validate_username(value) is False


@pytest.mark.parametrize(
    "email",
    [
        "a@b.c",
        "alice@example.com",
        "first.last+tag@mail.example.co.uk",
        "x@y.z",
    ],
)
def test_validate_email_accepts_valid_shapes(email):
    assert validate_email(email) is True


@pytest.mark.parametrize(
    "email",
    [
        "",
        "@example.com",  # missing local part
        "alice@",  # missing domain
        "aliceexample.com",  # missing @
        "alice@@example.com",  # more than one @
        "alice@example",  # domain is not dotted
        "alice example@example.com",  # spaces are not allowed
        "alice@example .com",
    ],
)
def test_validate_email_rejects_invalid_shapes(email):
    assert validate_email(email) is False


@pytest.mark.parametrize("value", [None, 123, b"a@b.c", [], {}])
def test_validate_email_rejects_non_strings(value):
    assert validate_email(value) is False
