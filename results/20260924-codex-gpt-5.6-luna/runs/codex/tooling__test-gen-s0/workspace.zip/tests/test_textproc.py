import pytest

from textproc import camel_to_snake, slugify, truncate, word_frequencies


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("Hello, World!", "hello-world"),
        ("  already---separated  ", "already-separated"),
        ("multiple\tlines\nand punctuation", "multiple-lines-and-punctuation"),
        ("", ""),
        ("---", ""),
        ("42 is the answer", "42-is-the-answer"),
        ("Café déjà vu", "café-déjà-vu"),
    ],
)
def test_slugify_normalizes_case_and_non_alphanumerics(value, expected):
    assert slugify(value) == expected


def test_slugify_supports_a_custom_separator_and_collapses_repeats():
    assert slugify("  One / two -- three  ", sep="_") == "one_two_three"
    assert slugify("a...b", sep="::") == "a::b"


def test_slugify_preserves_alphanumeric_unicode_characters():
    assert slugify("Привет мир 你好") == "привет-мир-你好"


def test_word_frequencies_counts_words_case_insensitively():
    text = "The quick brown fox; the QUICK fox."

    assert word_frequencies(text) == {"the": 2, "quick": 2, "brown": 1, "fox": 2}


def test_word_frequencies_accepts_internal_apostrophes_only():
    text = "Don't stop; don't—re-enter. 'quoted' rock'n'roll can't' 'tis"

    assert word_frequencies(text) == {
        "don't": 2,
        "stop": 1,
        "re": 1,
        "enter": 1,
        "quoted": 1,
        "rock'n": 1,
        "roll": 1,
        "can't": 1,
        "tis": 1,
    }


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("", {}),
        ("!!! 123 456 !!!", {"123": 1, "456": 1}),
        ("Café naïve résumé", {"caf": 1, "na": 1, "ve": 1, "r": 1, "sum": 1}),
    ],
)
def test_word_frequencies_handles_punctuation_digits_and_non_ascii_letters(text, expected):
    assert word_frequencies(text) == expected


@pytest.mark.parametrize(
    ("value", "length", "expected"),
    [
        ("short", 10, "short"),
        ("abcdef", 6, "abcdef"),
        ("abcdef", 5, "ab..."),
        ("abcdef", 3, "..."),
        ("abcdef", 2, ".."),
        ("abcdef", 1, "."),
        ("abcdef", 0, ""),
        ("", 4, ""),
    ],
)
def test_truncate_respects_the_requested_character_budget(value, length, expected):
    assert truncate(value, length) == expected


def test_truncate_counts_a_custom_ellipsis_in_the_budget():
    assert truncate("abcdefgh", 6, ellipsis="…") == "abcde…"
    assert truncate("abcdefgh", 2, ellipsis="[more]") == "[m"
    assert truncate("abcdefgh", 6, ellipsis="[more]") == "[more]"


def test_truncate_rejects_negative_lengths():
    with pytest.raises(ValueError, match="n must be >= 0"):
        truncate("text", -1)


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("CamelCase", "camel_case"),
        ("camelCase", "camel_case"),
        ("HTTPResponseCode", "http_response_code"),
        ("parseJSONData", "parse_json_data"),
        ("version2Value", "version2_value"),
        ("XML2HTTP", "xml2_http"),
        ("lowercase", "lowercase"),
        ("", ""),
    ],
)
def test_camel_to_snake_splits_case_boundaries_and_acronyms(name, expected):
    assert camel_to_snake(name) == expected


def test_camel_to_snake_leaves_existing_separators_and_handles_unicode():
    assert camel_to_snake("already_snake") == "already_snake"
    assert camel_to_snake("ÉclairTest") == "éclair_test"
