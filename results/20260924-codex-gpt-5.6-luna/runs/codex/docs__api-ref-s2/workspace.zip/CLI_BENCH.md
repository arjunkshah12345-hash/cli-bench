# CLI-Bench workspace

You are operating inside a benchmarked workspace.

- Work inside this directory. Do not write outside it.
- A programmatic verifier will grade the final state of this directory.
- Verify your own work before finishing.
