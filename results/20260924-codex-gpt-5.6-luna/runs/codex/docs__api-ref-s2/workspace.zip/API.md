# Text utilities API

Import the functions from `library`:

```python
from library import (
    chunk_list,
    flatten,
    pluralize,
    truncate_chars,
    valid_identifier,
)
```

The module does not use runtime type annotations or perform comprehensive type
validation. The types below are the intended input types; passing incompatible
objects can produce the built-in `TypeError` or `AttributeError` described for
each function.

## `chunk_list(items, size)`

Splits `items` into consecutive, shallow slices containing at most `size`
items. The last chunk may be shorter. An empty input produces an empty list.
The input is not modified.

### Parameters

- `items` (`list`): The list to split. In practice, any object supporting
  `len(items)` and integer slicing can be used.
- `size` (`int`): Maximum number of items per chunk. Must be at least `1`.

### Returns

`list[list]`: A new list of chunks. Each chunk is a shallow slice of `items`.

### Exceptions

- `ValueError`: Raised when `size < 1`.
- `TypeError`: Raised when `size` is not usable as an integer for `range`, or
  when `items` does not support `len()` and slicing as required by the
  implementation.

### Example

```python
chunk_list([1, 2, 3, 4, 5], 2)
# [[1, 2], [3, 4], [5]]
```

## `flatten(nested, max_depth=10)`

Flattens nested `list` objects into a single list, expanding lists only while
the current recursion depth is at most `max_depth`. Non-list values are kept as
is. Values at a depth beyond the limit—including a list that is no longer
expanded—are appended unchanged.

This is a depth limit, not general cycle detection: a self-referential or
mutually referential list is eventually kept as a list when the limit is
reached. Tuples and other sequence types are not flattened.

### Parameters

- `nested` (`list` or any object): The value to flatten. Only values whose
  runtime type is `list` (including list subclasses) are recursively expanded.
- `max_depth` (`int`, default `10`): Maximum recursion depth at which lists are
  expanded. The function does not validate that this is non-negative. A
  negative value therefore prevents expansion of the top-level list, while a
  sufficiently large value may hit Python's recursion limit for deeply nested
  input.

### Returns

`list`: A new flat list containing the non-list values found, plus any lists
that occur beyond `max_depth`.

### Exceptions

- `TypeError`: Raised if `max_depth` cannot be compared with an integer during
  depth checks. Other incompatible custom inputs may also raise a built-in
  exception while being iterated.
- `RecursionError`: May be raised for nesting deeper than Python can recurse
  into when `max_depth` is large enough to allow that nesting.

### Example

```python
flatten(["a", ["b", ["c"]]])
# ['a', 'b', 'c']
```

## `pluralize(word, count=None)`

Produces a naive English plural. Words ending in `s`, `x`, `z`, `ch`, or `sh`
get `-es`; words ending in a consonant followed by `y` change `-y` to `-ies`;
all other words get `-s`. If `count == 1`, the original word is returned
unchanged. No other spelling rules, capitalization rules, or irregular nouns
are handled.

### Parameters

- `word` (`str`): The singular word to transform.
- `count` (`int` or `None`, default `None`): Optional count. Only the exact
  comparison `count == 1` affects the result; any other value uses the plural
  rules.

### Returns

`str`: Either `word` unchanged when `count == 1`, or the generated plural.

### Exceptions

- `AttributeError`: Raised when `word` does not provide the string
  `endswith()` method.
- `TypeError`: May be raised when an incompatible `word` value is used with
  the string suffix operations or when a custom `count` value cannot be
  compared with `1`.

### Example

```python
pluralize("party")
# 'parties'

pluralize("apple", count=1)
# 'apple'
```

## `truncate_chars(s, n, ellipsis="…")`

Limits a string to `n` characters. If truncation is needed, the returned value
ends with `ellipsis`, and the ellipsis itself counts toward the `n`-character
limit. For `n == 0`, it returns the empty string. When `n` is no greater than
the length of `ellipsis`, the result is the first `n` characters of the
ellipsis rather than any part of `s`.

### Parameters

- `s` (`str`): The string to truncate.
- `n` (`int`): Maximum output length. Must be at least `0`.
- `ellipsis` (`str`, default `"…"`): Suffix used when truncation occurs. It
  may be an empty string.

### Returns

`str`: `s` when `len(s) < n`; otherwise a string of at most `n` characters
ending in the requested ellipsis (or its first `n` characters when the
ellipsis is longer than `n`).

### Exceptions

- `ValueError`: Raised when `n < 0`.
- `TypeError`: Raised when `n` is not usable for the numeric comparisons or
  string slicing, or when `s`/`ellipsis` are not compatible with `len`,
  slicing, and string concatenation.

### Example

```python
truncate_chars("A long sentence", 8)
# 'A long …'
```

## `valid_identifier(s)`

Checks whether `s` is a valid Python identifier and is not a Python keyword.
Thus, names such as `"item_name"` pass, while `"class"` fails even though it
has valid identifier characters.

### Parameters

- `s` (`str`): Candidate identifier text.

### Returns

`bool`: `True` only when `s.isidentifier()` is true and
`keyword.iskeyword(s)` is false.

### Exceptions

- `AttributeError`: Raised when `s` does not provide the string
  `isidentifier()` method.

### Example

```python
valid_identifier("item_name")
# True

valid_identifier("class")
# False
```
