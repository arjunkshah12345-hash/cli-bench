import pytest

from textproc import camel_to_snake, slugify, truncate, word_frequencies


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("Hello, World!", "hello-world"),
        ("  already---slugged  ", "already-slugged"),
        ("one\t two\nthree", "one-two-three"),
        ("version 2.0 (beta)", "version-2-0-beta"),
        ("Café déjà vu", "café-déjà-vu"),
        ("", ""),
        ("!!!", ""),
    ],
)
def test_slugify_normalizes_case_and_non_alphanumerics(value, expected):
    assert slugify(value) == expected


def test_slugify_collapses_runs_and_strips_separators_at_both_ends():
    assert slugify(" ... Multiple   separators!!! ") == "multiple-separators"


def test_slugify_accepts_a_custom_separator():
    assert slugify("A/B -- C", sep="_") == "a_b_c"


def test_slugify_keeps_alphanumeric_unicode_characters():
    assert slugify("影師嗎 — 42") == "影師嗎-42"


def test_word_frequencies_counts_words_case_insensitively():
    text = "Tea tea, TEA; coffee and tea."

    assert word_frequencies(text) == {"tea": 4, "coffee": 1, "and": 1}


def test_word_frequencies_keeps_internal_apostrophes_in_words():
    text = "Don't stop believin'. rock'n'roll O'NEIL"

    assert word_frequencies(text) == {
        "don't": 1,
        "stop": 1,
        "believin": 1,
        "rock'n": 1,
        "roll": 1,
        "o'neil": 1,
    }


def test_word_frequencies_ignores_standalone_apostrophes_and_non_ascii_words():
    text = "' leading 'trailing' 123 123abc café 中文"

    assert word_frequencies(text) == {
        "leading": 1,
        "trailing": 1,
        "123": 1,
        "123abc": 1,
        "caf": 1,
    }


def test_word_frequencies_returns_empty_dict_without_words():
    assert word_frequencies(" -- ... ' \n") == {}


@pytest.mark.parametrize(
    ("value", "length", "expected"),
    [
        ("short", 10, "short"),
        ("hello", 5, "hello"),
        ("hello", 4, "h..."),
        ("hello", 3, "..."),
        ("hello", 2, ".."),
        ("hello", 1, "."),
        ("hello", 0, ""),
        ("", 4, ""),
    ],
)
def test_truncate_respects_the_requested_total_length(value, length, expected):
    result = truncate(value, length)

    assert result == expected
    assert len(result) <= length


def test_truncate_uses_a_custom_ellipsis_and_counts_it_in_length():
    assert truncate("abcdefgh", 6, ellipsis="…") == "abcde…"
    assert truncate("abcdefgh", 2, ellipsis="[more]") == "[m"


def test_truncate_rejects_negative_lengths():
    with pytest.raises(ValueError, match="n must be >= 0"):
        truncate("hello", -1)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("CamelCase", "camel_case"),
        ("camelCase", "camel_case"),
        ("HTTPResponseCode", "http_response_code"),
        ("XMLHttpRequest", "xml_http_request"),
        ("version2Value", "version2_value"),
        ("JSON2API", "json2_api"),
        ("already_snake", "already_snake"),
        ("", ""),
    ],
)
def test_camel_to_snake_splits_word_boundaries_and_acronyms(value, expected):
    assert camel_to_snake(value) == expected


def test_camel_to_snake_does_not_split_an_acronym_into_individual_letters():
    assert camel_to_snake("parseHTTPResponse") == "parse_http_response"
