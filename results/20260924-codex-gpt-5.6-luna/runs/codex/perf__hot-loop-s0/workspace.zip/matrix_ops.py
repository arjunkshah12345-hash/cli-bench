"""Spatial utilities. count_pairs_within is the hot function."""

import math


def count_pairs_within(points, r):
    """Count unordered pairs (i, j), i < j, with dist(points[i], points[j]) <= r.

    Points are indexed in a uniform grid.  With cells of side ``r``, a point
    can only be within range of points in its own cell or one of the eight
    adjacent cells, so the quadratic all-pairs scan is avoided for sparse
    inputs.
    """
    n = len(points)
    if n < 2:
        return 0

    # The original implementation effectively treats a negative radius as
    # its absolute value because it compares against r * r.
    radius = abs(r)
    if radius == 0:
        # A zero-sized grid is not useful.  Group exact coordinate matches,
        # but retain the distance check so the comparison semantics remain
        # identical for unusual numeric values such as NaN.
        seen = {}
        count = 0
        for point in points:
            x, y = point
            key = (x, y)
            previous = seen.get(key)
            if previous is not None:
                px, py, occurrences = previous
                dx = x - px
                dy = y - py
                if dx * dx + dy * dy <= 0:
                    count += occurrences
                    seen[key] = (px, py, occurrences + 1)
            else:
                seen[key] = (x, y, 1)
        return count

    radius2 = radius * radius
    cell_size = radius
    cells = {}
    count = 0

    for point in points:
        x, y = point
        cell_x = math.floor(x / cell_size)
        cell_y = math.floor(y / cell_size)

        for neighbor_x in range(cell_x - 1, cell_x + 2):
            for neighbor_y in range(cell_y - 1, cell_y + 2):
                for px, py in cells.get((neighbor_x, neighbor_y), ()):
                    dx = x - px
                    dy = y - py
                    if dx * dx + dy * dy <= radius2:
                        count += 1

        cells.setdefault((cell_x, cell_y), []).append((x, y))

    return count


def total_path_length(points):
    """Sum of distances of a closed path (used elsewhere; leave as-is)."""
    if len(points) < 2:
        return 0.0
    total = 0.0
    for i in range(len(points)):
        a, b = points[i], points[(i + 1) % len(points)]
        total += math.dist(a, b)
    return total
